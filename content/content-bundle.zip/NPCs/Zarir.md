Tidligere PC, turned NPC and vampirespawn etter han ble bortført av [[Strahd von Zarovich|Strahd]] i [[Session 9 - Church fight]].

Fant han igjen i [[Session 12 - Visiting Strahd]] i [[Castle Ravenloft]]

![](https://cdn.discordapp.com/attachments/759006740464926762/888017840320417853/tempFileForShare_20210916-130544.jpg)