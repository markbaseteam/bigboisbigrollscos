---
aliases: [Rictavio]
---

Gjemmer seg i [[Vallaki]]. Litt gal, vil angripe [[Strahd von Zarovich|Strahd]] allerede.
Har lett etter [[Sun Sword]], som han mener er i [[Castle Ravenloft]].
Liker ikke Vistani, siden han mener de støtter Strahd
Har en tiger

![](https://cdn.discordapp.com/attachments/759006740464926762/895734522061144124/152-636623995708971736.png)