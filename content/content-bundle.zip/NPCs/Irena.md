Kidnappet av [[Strahd von Zarovich]], holdes fange i [[Castle Ravenloft]]

Hyret adventurers (oss) for å hindre Strahd i å bortføre henne slik at hun skulle slippe å gifte seg med han.
Har det tilsynelatende bra i slottet til Strahd. Kanskje enchanted?

Har en bror som for øyeblikket bor i [[Vallaki]]