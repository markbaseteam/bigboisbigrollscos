
Krøllete rødt hår, peg leg, main character syndrome

Familie med [[Rudolph van Richten]]

Eier av tårnet ute i innsjøen vest for [[Vallaki]], [[Van Richten's Tower]]

![](https://cdn.discordapp.com/attachments/759006740464926762/947926085767663656/146-636623997177812461.png)