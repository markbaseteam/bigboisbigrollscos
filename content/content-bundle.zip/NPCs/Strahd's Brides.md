"Gift" med [[Strahd von Zarovich|Strahd]]

3 noblewomen

- Ludmilla
- Anastrasjya
- Volenta (kutter opp dyr)

Også Escher, som egentlig skulle være mann

[[Zarir]] har blitt en av disse?

Vampirespawn, men sterkere