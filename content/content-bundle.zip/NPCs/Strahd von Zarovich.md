---
aliases: [Strahd, the vampire]
---
Obsessed with [[Irena]]
Owns [[Castle Ravenloft]]
Ancient [[Vampire]]
Access to 3rd level spells, perhaps higher.
Can transform into a cloud of bats
Dangerous enchantment magic

Virker interessert i hvilken type personer [[Muna Chai|Muna]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Erytar]] og [[Blanche]] er.

![](https://static.wikia.nocookie.net/forgottenrealms/images/e/ee/Strahd-5e.jpg/revision/latest?cb=20180825201600)