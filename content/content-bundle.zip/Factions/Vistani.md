Vandrende folk som kanskje tilhørerer [[Strahd von Zarovich|Strahd]].
Leste fra [[Tarokka Cards]] for oss.
Hatet av [[Rudolph van Richten]]
Vi reddet en fra [[Argynvostholt]] i [[Session 5 - Haunted mansion dead dragon]]