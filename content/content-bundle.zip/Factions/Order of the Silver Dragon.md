Holder til i [[Argynvostholt]].
Vil at vi skal hente [[Bones of Argynvost]] fra [[Castle Ravenloft]].
Lederen har et fett sverd som vi kanskje skal stjele.