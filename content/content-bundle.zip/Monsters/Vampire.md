Don't like radiant or sunlight
Strong ones require a wooden stake to be killed
[[Strahd von Zarovich|Strahd]], [[Strahd's Brides]], [[Zarir]]
![](https://cdn.discordapp.com/attachments/759006740464926762/1029086516011618345/tempFileForShare_20221010-194151.jpg)