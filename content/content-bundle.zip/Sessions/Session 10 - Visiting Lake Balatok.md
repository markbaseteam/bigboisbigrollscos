2022-05-23
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]] og [[Erytar]]
Location: [[Vallaki]], the road west, [[Van Richten's Tower]]

Previous: [[Session 9 - Church fight]]
Next: [[Session 11 - Leaving Lake Balatok and answering the invitation]]