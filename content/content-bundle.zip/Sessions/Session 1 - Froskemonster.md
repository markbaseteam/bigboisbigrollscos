2022-10-31
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Lake Zarovich]]

Bonesaw sin første, vi banket et froskemonster

Next: [[Session 2 - Trollmann i nord]]