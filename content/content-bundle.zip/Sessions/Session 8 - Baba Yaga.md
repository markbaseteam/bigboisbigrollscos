2022-05-02
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]], the road south, the Hag Hut

Vi denger en uskyldig hag som har stjålet en av de tre [[Stones of Growth]]. Etterpå returnerer vi steinen til [[Wizards of Wines]] og drar mot [[Vallaki]] igjen

Previous: [[Session 7 - Yester Hill]]
Next: [[Session 9 - Church fight]]