2022-06-06
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]] og [[Erytar]]
Location: [[Van Richten's Tower]], [[Vallaki]], the road east

Etter vi avklarer situasjonen med [[Female van Richten]] drar vi tilbake til Wallachi.
Vi bestemmer oss endelig for å dra mot [[Castle Ravenloft]], ettersom vi ble invitert av [[Strahd von Zarovich|Strahd]] i [[Session 5 - Haunted mansion dead dragon]]
Vi begynner å dra i kjerra han har gjort klar for oss, men den ser veldig satan-esque ut. Vi blir derfor angrepet av peasants som tror vi er onde. Erytar popper flere av dem med spike growth, vi prøver å kommunisere at vi ikke vil dem vondt.


Previous: [[Session 10 - Visiting Lake Balatok]]
Next: [[Session 12 - Visiting Strahd]]