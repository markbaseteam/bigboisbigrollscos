2022-02-07, 2022-01-31
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]]

Vi fant kidden til ordføreren i overetasjen på ordførervillaen og sendte ham til [[Trollmann i nord]]. Han prøvde å lære seg teleportering (spesifikt ut av domenet), som har vist seg å ikke funke så bra.
Vi fikk også wooden stakes av en [[Rudolph van Richten]] som har gjemt seg i Vallaki

![](https://cdn.discordapp.com/attachments/759006740464926762/940329322634424360/061-cos05-12.png)

Previous: [[Session 3 - Who's ready for a revolution]]
Next: [[Session 5 - Haunted mansion dead dragon]]