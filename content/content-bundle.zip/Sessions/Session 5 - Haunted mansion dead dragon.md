2022-02-28, 2022-02-21, 2022-02-14
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]], the road west, then south, [[Argynvostholt]]

Denne sessionen er slått sammen fra flere andre, ettersom notatene begynte mye senere.

Vi reiste mot Argynvostholt og bekjempet edderkopper. Vi reddet en dusk elf, møtte [[Female van Richten]] som ble stalket av en av [[Strahd von Zarovich|Strahd]]s servants. Denne servanten ga oss en invitasjon til å besøke [[Castle Ravenloft]], vi prøvde å mislede servanten for å redde van Richten.

![Servant of Strahd](https://cdn.discordapp.com/attachments/759006740464926762/947909296493043772/081-cos07-05.png)

---

My friends,

Know that it is I who have brought you to this land, my home, and know that I alone can release you from it. I bid you dine at my castle so that we can meet in civilized surroundings. Your passage here will be a safe one. I await your arrival. 

Your host, Strahd von Zarovich

---

Vi ble angrepet av sterke undead riddere i kapellet, og fant sopper som gjør at man vokser/krymper.

Vi møtte lederen av ridderene i tredje etasje, og lovet å hente drageskjelettet tilbake til Argynvostholt. Vi dro så tilbake til Vallaki.

Previous: [[Session 4 - Ung trollmann i taket]]
Next: [[Session 6 - Wizards of Wines]]