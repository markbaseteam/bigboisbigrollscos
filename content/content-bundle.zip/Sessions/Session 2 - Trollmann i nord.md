2021-12-02
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: North of [[Lake Zarovich]], [[Mount Baratok]]

Vi besøkte en trollmann i nord, [[Trollmann i nord]].
Vi dro også til dukkemakeren i byen, og Muna pratet med han

![](https://cdn.discordapp.com/attachments/759006740464926762/916073456846663710/065-cos05-15.png)

Previous: [[Session 1 - Froskemonster]]
Next: [[Session 3 - Who's ready for a revolution]]