2022-10-31
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]] og [[Erytar]]
Location: [[Castle Ravenloft]]

Vi er inne i ballrommet til [[Strahd von Zarovich]], og danser med hans tre bruder, [[Strahd's Brides]] og en ekstra. Strahd takker for laget og eskorterer oss opp en spiraltrapp. Der henter han [[Irena]] (etter en uhørt samtale bak lukket dør), som er glad for å se oss og spør om vi er der for bryllupet.
Dato for bryllupet er ikke satt, men broren til Irena er også invitert.

Etter Strahd går inn på rommet igjen bestemmer vi oss for å utforske. Vi fortsetter opp trappa i et høyt tårn, der det var en svevende krystall høyt oppe. Når vi nærmer oss den begynte hele tårnet å riste. Animated Halberds begynte å angripe oss, og vampire spawn dukket opp.

Sessionen sluttet mens vi fortsatt fightet

Previous: [[Session 13 - Dinner with Strahd]]
Next: 