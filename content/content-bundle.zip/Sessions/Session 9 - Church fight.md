2022-05-10
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]]

[[Calgras Holykeeper]] bidrar til å beskytte menneskene i kirken
[[Zarir]] blir bortført av [[Strahd von Zarovich|Strahd]] etter [[Muna Chai|Muna]] kaster alt hun har på han, og han retaliater med en fireball

Previous: [[Session 8 - Baba Yaga]]
Next: [[Session 10 - Visiting Lake Balatok]]