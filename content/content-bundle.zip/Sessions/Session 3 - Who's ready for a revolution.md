2022-01-17
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]]

Vi ankommer byen og legger oss for natten, når vi våkner er det solfestival.
Landsbyen har bygget en stor sol av tre og greiner som skal antennes.
En uskyldig person skulle bli henrettet, noe vi ikke likte.
Branko styrte en uprising mot ordføreren og kumpanene hans, og ble den nye ordføreren.

Previous: [[Session 2 - Trollmann i nord]]
Next: [[Session 4 - Ung trollmann i taket]]