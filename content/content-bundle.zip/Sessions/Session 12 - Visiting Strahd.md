2022-09-26
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]] og [[Erytar]]
Location: The road east, [[Castle Ravenloft]]

Fortsatte turen til [[Castle Ravenloft]], begynner middag med [[Strahd von Zarovich|Strahd]]

Previous: [[Session 11 - Leaving Lake Balatok and answering the invitation]]
Next: [[Session 13 - Dinner with Strahd]]
