2022-10-10
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]] og [[Erytar]],
Location: [[Castle Ravenloft]]

Spiste middag med [[Strahd von Zarovich|Strahd]] og [[Strahd's Brides]]. 

Danset med de samme etterpå.

[[Strahd's Brides]] pønsker på noe, og kan være på lag med oss mot [[Strahd von Zarovich|Strahd]]

Previous: [[Session 12 - Visiting Strahd]]
Next: [[Session 14 - Finding Irena]]