2022-03-28
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Yester Hill]], [[Wizards of Wines]]

På Yester Hill finner vi en mega wicker-[[Strahd von Zarovich|Strahd]] som vi ender opp med å banke for å finne en av de tre[[Stones of Growth]]. Vi får også tak i en magisk øks som gjør mer damage på plantebaserte creatures, men gjør damage på en selv om man ikke er Good.

Vi returnerer så til [[Wizards of Wines]] og drar mot [[Vallaki]]

Previous: [[Session 6 - Wizards of Wines]]
Next: [[Session 8 - Baba Yaga]]