2022-03-21 og 2022-03-14
Cast: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Muna Chai|Muna]], [[Erytar]] og [[Zarir]]
Location: [[Vallaki]], the road west, [[Wizards of Wines]], [[Yester Hill]]

Vi bestemmer oss endelig for å undersøke hvorfor det ikke kommer mer vin.
Når vi ankommer wizards of wines blir vi angrepet av veldig mange twig blights og druids som har tatt over vingården.

Ifølge eierene har de tre magiske grønne steinene blitt stjålet, og uten dem kan de ikke dyrke vinen. De forteller oss at en av dem er i [[Yester Hill]], som vi ankommer når sessionen slutter.

Previous: [[Session 5 - Haunted mansion dead dragon]]
Next: [[Session 7 - Yester Hill]]