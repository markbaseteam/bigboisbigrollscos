Ligger vest for [[Vallaki]] og nord for [[Yester Hill]]

Vingården og hjemmet til familien som er ansvarlige for å brygge vin for hele [[Barovia]].

[[Vallaki]] har vært uten ny vin siden [[Stones of Growth]] har blitt stjålet.


Vi kom hit i [[Session 6 - Wizards of Wines]], og var her sist i [[Session 8 - Baba Yaga]] når vi leverte tilbake den andre stenen.