Ligger sørvest for [[Vallaki]]

Hjemmet til en avdød ridder-orden ([[Order of the Silver Dragon]]) som kriget mot [[Strahd von Zarovich|Strahd]], ledet av en silver dragon.
Dragens skjelett er tatt med til Castle Ravenloft, og vi burde ta med restene tilbake til Argynvostholt, for å gi den en proper burial

Lederen av ridderene har et magisk sverd som kan bli nyttig i fremtiden.

Vi var her i [[Session 5 - Haunted mansion dead dragon]]

---
My knights have fallen, and this land is lost. The armies of my enemy will not be stopped by sword or spell, claw or fang. Today I will die, not avenging those who have fallen, but defending that which I love—this valley, this home, and the ideals of the Order of the Silver Dragon. 

The evil surrounds me. The time has come to throw off this guise and show these heathens my true fearsome form. Let it spark terror in their hearts! Let them tell their stories of dark triumph against the protector of the Balinok Mountains! Let Argynvost be remembered as a dragon of honor and valor. My one regret is that my remains will not lie in their rightful place, in the hallowed mausoleum of Argynvostholt. No doubt my bones will be scattered among my enemies like the coins of a plundered hoard, trophies of a hard-won victory. 

I do not fear death. Though my body will die, my spirit will live on. Let it serve as a beacon of light against the darkness. Let it bring hope to a land wrought with despair. 

Now, to battle! 

A

---

![](https://cdn.discordapp.com/attachments/759006740464926762/942853177311641700/076-cos07-02.png)