Hjemmet til [[Trollmann i nord]] (cirka)
Vi var her i [[Session 2 - Trollmann i nord]] og leverte en ung trollmann her i [[Session 4 - Ung trollmann i taket]]