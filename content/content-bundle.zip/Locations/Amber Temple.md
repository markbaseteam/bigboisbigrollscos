Fortress of evil defended by forces of good

Inneholder veldig nyttige ting, men vi er for øyeblikket for svake for å bekjempe det som er inni

Husker ikke hvem som nevnte denne, sikker [[Rudolph van Richten|Rictavio]] rundt [[Session 4 - Ung trollmann i taket]]