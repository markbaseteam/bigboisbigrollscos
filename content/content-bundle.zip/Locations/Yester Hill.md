Stedet druid brukte for å bygge Wicker-[[Strahd von Zarovich|Strahd]], som vi beseiret i [[Session 7 - Yester Hill]]. Her fikk vi tak i den første av de tre [[Stones of Growth]]

![](https://cdn.discordapp.com/attachments/759006740464926762/955524982119759892/unknown.png)

![](https://cdn.discordapp.com/attachments/759006740464926762/958056742384709662/tumblr_pmgvcjVgY91rfyiu4o1_1280.png)