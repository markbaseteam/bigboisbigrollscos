Et høyt tårn ute på en øy i innsjøen nordvest for [[Vallaki]] som heter Lake Balatok
Eid av [[Female van Richten]]
Vi er velkommen så ofte vi vil
Ikke veldig nyttig, ettersom vi eier et hus i [[Vallaki]]

Vi var her i [[Session 10 - Visiting Lake Balatok]] og [[Session 11 - Leaving Lake Balatok and answering the invitation]]

Dør må åpnes med en spesifikk dans, ellers utsettes hele øyen for [Lightning Bolt](https://5e.tools/spells.html#lightning%20bolt_phb)

![](https://cdn.discordapp.com/attachments/759006740464926762/983403840646819840/unknown.png)
![](https://cdn.discordapp.com/attachments/759006740464926762/978332356932939886/unknown.png)