Created over 300 years ago by [[Strahd von Zarovich]]

Tall towers, animated weapons and servants, lots of vampire spawn

Vi ankom her i [[Session 12 - Visiting Strahd]]

![](https://cdn.discordapp.com/attachments/759006740464926762/940318696184873020/tempFileForShare_20220207-195035.jpg)

![](https://cdn.discordapp.com/attachments/759006740464926762/817105793378943016/castle.png)