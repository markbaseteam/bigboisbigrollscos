Domenet til [[Strahd von Zarovich|Strahd]]. 
Partyet ble hyret for å eskortere [[Irena]], men ble fanget i Barovia.
Ingenting kan forlate Barovia, teleportation spells ut er veldig farlige.