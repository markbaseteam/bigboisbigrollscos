---
aliases: [Our town]
---
Posisjonert veldig sentralt i [[Barovia]], med veier til det meste som er relevant.
Relativt stor landsby med smithy, kirke, ordførerhus (vårt) og dukkemaker.
[[Calgras Holykeeper]] bor i kirka
[[Branko 'Bonesaw' Reznik|Branko]] ble ordfører etter en revolusjon i [[Session 3 - Who's ready for a revolution]]
[[Strahd von Zarovich|Strahd]] angrep kirken og bortførte [[Zarir]] i [[Session 9 - Church fight]]
Mange av landsbyfolkene skylder på oss for å ha blitt syke på grunn av vinen vi tok med fra [[Wizards of Wines]], og angrep oss i [[Session 11 - Leaving Lake Balatok and answering the invitation]]