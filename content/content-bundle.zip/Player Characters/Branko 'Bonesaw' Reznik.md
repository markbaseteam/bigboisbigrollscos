---
aliases: [Branko, Bonesaw]
---
All members: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Erytar]] og [[Muna Chai|Muna]]
Devotion Paladin

Mayor of [[Vallaki]]

Har en hest ![](https://cdn.discordapp.com/attachments/759006740464926762/970757789691572224/Blakken.png)