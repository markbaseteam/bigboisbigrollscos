All members: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Erytar]] og [[Muna Chai|Muna]]
Rogue

![](https://cdn.discordapp.com/attachments/759006740464926762/888036393551560704/invictus-gaming-fiora-splash-art-lol-uhdpaper.com-4K-62.jpg)