All members: [[Blanche]], [[Branko 'Bonesaw' Reznik|Bonesaw]], [[Erytar]] og [[Muna Chai|Muna]]
Hall of Fame: [[Zarir]]
Party loot: [The Stash](https://hackmd.io/KFsB5vODRMiWDQSpE9yI-Q)

Originally hired to defend [[Irena]], things took a turn when [[Strahd von Zarovich|Strahd]] kidnapped her and brought her to [[Castle Ravenloft]]! Hijinx ensue as the party defeats monsters, saves villagers and lays dead creatures to their final rest.