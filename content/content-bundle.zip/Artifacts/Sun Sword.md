Farlig for vampyrer?
Gjemt i [[Castle Ravenloft]]
Kan drepe [[Strahd von Zarovich|Strahd]]?