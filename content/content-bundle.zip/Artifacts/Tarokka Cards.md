Spådommer fra vistani.

Mange peker mot [[Castle Ravenloft]], og skal hjelpe oss å bekjempe [[Strahd von Zarovich|Strahd]]

Kort 1, 2 og 3 har blitt erstattet av nye kort.

  - Kort 1: This card tells of history. Knowledge of the ancient will help you better understand your enemy. 
	  - ~~4 of Swords—Mercenary The thing you seek lies with the dead, under mountains of gold coins. ~~
	  - 2 of Glyphs - Missionary: I see a garden dusted with snow, watched over by a scarecrow with a sackcloth grin. Look not to the garden but to the guardian.
  
  - Kort 2: This card tells of a powerful force for good and protection, a holy symbol of great hope.
	  - ~~9 of Coins—Miser Look for a fortress inside a fortress, in a place hidden behind fire. ~~
	  - 7 of Swords - Hooded One: I see a faceless god. He awaits you at the end of a long and winding road, deep in the mountains.
	  
  - Kort 3: This is a card of power and strength. It tells of a weapon of vengeance: a sword of sunlight.  [[Sun Sword]]
	  - ~~6 of Stars—Evoker Search for the crypt of a wizard ordinaire. His staff is the key. ~~
	  - 2 of Swords - Paladin: I see a sleeping prince, a servant of light and the brother of darkness. The treasure lies with him.
	  
  - Kort 4: This card sheds light on one who will help you greatly in the battle against darkness.
	  - Seer: Look for a dusk elf living among the Vistani. He has suffered a great loss and is haunted by dark dreams. Help him, and he will help you in return. 
  
  - Kort 5: Your enemy is a creature of darkness, whose powers are beyond mortality. This card will lead you to him! 
	  - Raven: Look to the mother's tomb.