3 stjålet fra [[Wizards of Wines]] av [[Strahd von Zarovich|Strahd]]s undersåtter 
En ble funnet i [[Yester Hill]]
En annen ble tatt tilbake fra [[Baba Yaga]]
Altså er to tilbake, men en tredje er fortsatt MIA